/*
set PATH=%PATH%;C:\Arduino\arduino-1.0\hardware\tools\avr\bin
set PATH=%PATH%;C:\arduino\arduino-1.0\hardware\tools\avr\etc

cd %TEMP%
dir *.hex /s

cd C:\Users\BRIANC~1.001\AppData\Local\Temp\build5703187254703185841.tmp

avr-objdump.exe -S sketch_sep22a.cpp.elf > C:\Temp\dump.cpp & C:\Temp\dump.cpp
*/

int main(void)
{
	for (;;);
	return 0;
}
